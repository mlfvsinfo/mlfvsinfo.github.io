Default username password:
aname
pass

Note:  In windows 7 please press ENTER to commit changes where no OK button is present;
EG: in Auto Testing dialog, after entering a custom name for the auto test, press enter to commit the new name.  If you do not, then the new name will be lost when you click back.