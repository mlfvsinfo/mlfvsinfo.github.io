INSTALLATION INSTRUCTIONS  

Download the cp3068software.zip file. Unzip the files to a temporary folder.

1.If you can install things on your computer:

	-Run "dotnetfx35setup.exe".
	-Run �setup.msi�.
	-This will install the network design tool.
	-A shortcut to the tool can be found under Start->Programs->"wlvNET Educational Network Design Tool v1.1.1".
	-The installer will complain or fail if the .NET framework isn't installed. 

2.If you cannot install things on your computer:

	-Open the lifeboat folder in the temporary directory.
	-Run "Network Design Tool.exe"

